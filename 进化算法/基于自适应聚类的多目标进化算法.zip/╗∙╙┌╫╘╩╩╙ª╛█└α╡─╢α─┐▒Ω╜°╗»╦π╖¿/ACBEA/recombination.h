#pragma once
#include "solution.h"

void exchangeAndSort(Solution &major, Solution &minor, int start, int end)
{
	//��ȡ��Ҫ��������Ĺ������ڴ�Ҫ���ϵ�λ��
	int interval = end - start + 1;
	int *part = new int[interval];
	for (int i = 0; i < interval; i++)
	{
		for (int j = 1; j <= jobCount; j++)
		{
			if (major.jobSequence[i + start] == minor.jobSequence[j])
			{
				part[i] = j;
				break;
			}
		}
	}

	//����
	bool exchange;
	int x1, x2, temp, temp2;
	for (int m = 0; m < interval - 1; m++)
	{
		exchange = false;
		for (int n = interval - 1; n > m; n--)
		{
			x1 = part[n - 1];
			x2 = part[n];
			if (x1 > x2)//ǰ��Ⱥ����
			{
				temp2 = part[n - 1];
				part[n - 1] = part[n];
				part[n] = temp2;
				exchange = true;

				temp = major.jobSequence[n - 1 + start];
				major.jobSequence[n - 1 + start] = major.jobSequence[n + start];
				major.jobSequence[n + start] = temp;
			}
		}
		if (!exchange) break;
	}

	delete[] part;
}

//���㽻��
void twoPointCrossover(Solution &parent1, Solution &parent2, Solution& child1, Solution& child2)
{
	if ((rand() % 100 / (double)101) < pc)
	{
		int start, end;//����ȷ���������������λ��
		int temp;
		do
		{
			start = rand() % jobCount + 1;
			end = rand() % jobCount + 1;
		} while (start == end);

		if (start > end)
		{
			temp = start;
			start = end;
			end = temp;
		}

		for (int m = 1; m <= jobCount; m++)
		{
			child1.jobSequence[m] = parent1.jobSequence[m];
			child2.jobSequence[m] = parent2.jobSequence[m];
		}

		exchangeAndSort(child1, parent2, start, end);
		exchangeAndSort(child2, parent1, 1, start - 1);
		exchangeAndSort(child2, parent1, end + 1, jobCount);

		if ((end - start)<(jobCount / 3))
		{
			for (int m = 1; m <= jobCount; m++)
			{
				child1.jobSequence[m] = child2.jobSequence[m];
			}
		}
	}
	else
	{
		for (int m = 1; m <= jobCount; m++)
		{
			child1.jobSequence[m] = parent1.jobSequence[m];
			child2.jobSequence[m] = parent2.jobSequence[m];
		}
	}
}

//��������
void interChangeMutation(Solution& child1)
{
	if ((rand() % 100 / (double)101) < pm)
	{
		int position1, position2;	//��������Ĺ����������е�λ��
		int temp;					//��ʱ����
		do
		{
			position1 = rand() % jobCount + 1;
			position2 = rand() % jobCount + 1;
		} while (position1 == position2);
		temp = child1.jobSequence[position1];
		child1.jobSequence[position1] = child1.jobSequence[position2];
		child1.jobSequence[position2] = temp;
	}
}