#include "stdafx.h"
#include "Func.h"

int main()
{
	//MODDE��APMO��MOEAD��BODE
	int dominatedCount;
	double coverage, sum;

	for (int k = 1; k <= 3; k++)
	{
		jobCount = k * 100;
		for (int m = 3; m <= 5; m += 2)
		{
			sum = 0;
			cout << "ACBEA_C-ACBEA" << jobCount << "-" << m << "-" << "l:";
			for (int n = 1; n <= 10; n++)
			{
				char filenameA[100];
				sprintf_s(filenameA, ".\\Data\\largeJob\\ACBEA_C\\ACBEA_C-%d-%d-%d-l.txt", jobCount, m, n);
				ifstream finA;
				finA.open(filenameA);
				int i = 0;
				while (!finA.eof())
				{
					i++;
					finA >> sampleA[i][0] >> sampleA[i][1];
				}
				finA.close();
				sampleCountA = i - 1;

				char filenameB[100];
				sprintf_s(filenameB, ".\\Data\\largeJob\\ACBEA\\ACBEA-%d-%d-%d-l.txt", jobCount, m, n);
				ifstream finB;
				finB.open(filenameB);
				int j = 0;
				while (!finB.eof())
				{
					j++;
					finB >> sampleB[j][0] >> sampleB[j][1];
				}
				finB.close();
				sampleCountB = j - 1;

				dominatedCount = compare();//�Ƚ�
				coverage = (double)dominatedCount / sampleCountB;
				sum += coverage;
				//cout << coverage << " ";
			}
			cout << sum / 10 << endl;
		}
	}

	for (int k = 1; k <= 3; k++)
	{
		jobCount = k * 100;
		for (int m = 3; m <= 5; m += 2)
		{
			sum = 0;
			cout << "ACBEA_C-ACBEA" << jobCount << "-" << m << "-" << "s:";
			for (int n = 1; n <= 10; n++)
			{
				char filenameA[100];
				sprintf_s(filenameA, ".\\Data\\smallJob\\ACBEA_C\\ACBEA_C-%d-%d-%d-s.txt", jobCount, m, n);
				ifstream finA;
				finA.open(filenameA);
				int i = 0;
				while (!finA.eof())
				{
					i++;
					finA >> sampleA[i][0] >> sampleA[i][1];
				}
				finA.close();
				sampleCountA = i - 1;

				char filenameB[100];
				sprintf_s(filenameB, ".\\Data\\smallJob\\ACBEA\\ACBEA-%d-%d-%d-s.txt", jobCount, m, n);
				ifstream finB;
				finB.open(filenameB);
				int j = 0;
				while (!finB.eof())
				{
					j++;
					finB >> sampleB[j][0] >> sampleB[j][1];
				}
				finB.close();
				sampleCountB = j - 1;

				dominatedCount = compare();//�Ƚ�
				coverage = (double)dominatedCount / sampleCountB;
				sum += coverage;
				//cout << coverage << " ";
			}
			cout << sum / 10 << endl;
		}
	}

	system("pause");
	return 0;
}
