//Algorithm  RNAN
#include <iostream>
#include<ctime>
#include<fstream>
#include<cstring>
#include<cmath>
#include<vector>
#include<algorithm>
#include <IO.h>
using namespace std;
const int JOB_COUNT=180;
const int JF=3;
const int B=50;
const int M=3;
int result[10]={0}; //copy  10 results
 class JOB
{
    public:
        int JID;
        int JFamily;
        int JPtime;
        int JSize;
};
class Batch
{
    public:
        int BID;
        int Bfamily;
        int Bptime;
        int used_space;
        int unused_space;
        int exist[JOB_COUNT];
};
class Machine
{
    public:
        int MID;
        int Mcomplatetime;
    public:
        void initmachine();
    };
void Machine::initmachine()
{
    MID=0;
    Mcomplatetime=0;
}

int  sort(vector<Machine>  &mach,int n)
{
    bool mSwap=false;
    do
    {
        mSwap=false;
        for(int i=1;i<n;i++)
        {
            if(mach[i].Mcomplatetime<mach[i-1].Mcomplatetime)
            {
                swap(mach[i],mach[i-1]);
                mSwap=true;
            }
        }
    }while(mSwap);
    return 0;
}

//RNRN sort processing
int RNRN(JOB *job)
{
//    int sum=0;  //Mark as Cmax;
    //For a job family , sort the job in a random order;
    JOB jobchange;
    for(int index=0;index<JF;index++)
    {
        for(int i=index*(JOB_COUNT/JF);i<(index*JOB_COUNT/JF+(JOB_COUNT/JF)/2);i++)
        {
             int t=rand()%(JOB_COUNT/JF)+index*(JOB_COUNT/JF);
             jobchange=job[i];
             job[i]=job[t];
             job[t]=jobchange;
        }
    }

//    for(int i=0;i<JOB_COUNT;i++)
//	{
//		cout<<job[i].JID<<"\t"<<job[i].JFamily<<"\t"<<job[i].JPtime<<"\t"<<job[i].JSize<<endl;;
//	}
    //Batch the jobs ,use FF heuristic;
    Batch batch[JOB_COUNT];
    //Batch *p=batch;
    for(int x=0;x<JOB_COUNT;x++)
		for(int y=0;y<JOB_COUNT;y++)
		     batch[x].exist[y]=-1;
    batch[0].BID=0;
    batch[0].Bfamily=job[0].JFamily;
	batch[0].Bptime=job[0].JPtime;
	batch[0].unused_space=B-job[0].JSize;
	batch[0].used_space=job[0].JSize;
    batch[0].exist[0]=job[0].JID;
    int k=0;  //Marked as current used BID
    for(int i=1;i<JOB_COUNT;i++)
    {
         int flag=0;
         for(int j=0;j<=k&&i<JOB_COUNT;j++)  //FF heuristic, job send to the best fit batch
          {
             if(batch[j].unused_space>=job[i].JSize&&batch[j].Bfamily==job[i].JFamily)
             {
                 batch[j].unused_space-=job[i].JSize;
                 batch[j].used_space+=job[i].JSize;
                 int t=0;
                 while(batch[j].exist[t]!=-1) t++;
                 batch[j].exist[t]=job[i].JID;
                 flag=1;
                 break;
             }
         }
         if(flag==0)   //no fited batch ,new one
         {
             k++;
             batch[k].BID=k;
             batch[k].Bfamily=job[i].JFamily;
             batch[k].Bptime=job[i].JPtime;
             batch[k].unused_space=B-job[i].JSize;
             batch[k].used_space=job[i].JSize;
             batch[k].exist[0]=job[i].JID;
         }

    }
    // for(int i=0;i<=k;i++)
     //{
     //    cout<<batch[i].BID<<" \t"<< batch[i] .Bfamily<<" \t"<<batch[i].Bptime<<endl;
     //}


        // cout<<k<<"***********"<<endl;
//    for(int i=0;i<k;i++)
//    {
//        cout<<batch[i].BID<<"\t";
//        int j=0;
//        while(batch[i].exist[j]!=-1)
//            {
//                cout<<batch[i].exist[j]<<"   ";
//                j++;
//            }
//            cout<<endl;
//    }

     //upset batch order
     Batch  tempbatch;
     for(int pointer=0;pointer<k/2;pointer++)
     {
         int temp=rand()%k+1;
        // tempbatch.BID=batch[pointer].BID;
         tempbatch.Bfamily=batch[pointer].Bfamily;
         tempbatch.Bptime=batch[pointer].Bptime;
         tempbatch.unused_space=batch[pointer].unused_space;
         tempbatch.used_space=batch[pointer].used_space;
         memcpy(tempbatch.exist,batch[pointer].exist,JOB_COUNT);
         //batch[pointer].BID=batch[temp].BID;
         batch[pointer].Bfamily=batch[temp].Bfamily;
         batch[pointer].Bptime=batch[temp].Bptime;
         batch[pointer].unused_space=batch[temp].unused_space;
         batch[pointer].used_space=batch[temp].used_space;
         memcpy(batch[pointer].exist,batch[temp].exist,JOB_COUNT);
         //batch[temp].BID= tempbatch.BID;
         batch[temp].Bfamily=tempbatch.Bfamily;
         batch[temp].Bptime=tempbatch.Bptime;
         batch[temp].unused_space=tempbatch.unused_space;
         batch[temp].used_space=tempbatch.used_space;
         memcpy(batch[temp].exist,tempbatch.exist,JOB_COUNT);
     }

    //assign batch to machine
    vector<Machine>  machine;
    Machine newmachine;
    for(int i=0;i<M;i++)
    {
        newmachine.MID=i+1;
        newmachine.Mcomplatetime=0;
        machine.push_back(newmachine);
        newmachine.initmachine();
    }

     for(int  pro=0;pro<k;pro++)
     {
         sort(machine,machine.size());
        machine[0].Mcomplatetime+=batch[pro].Bptime;
      }

    sort(machine,machine.size());
    return machine[M-1].Mcomplatetime;
}

//LFLN sort process
int LFRN(JOB *job)
{
     //   int sum=0;  //Mark as Cmax;
    //For a job family , sort the job in a decreasing order;
    JOB jobchange;
    for(int index=0;index<JF;index++)
    {
        for(int i=index*(JOB_COUNT/JF);i<(index+1)*JOB_COUNT/JF;i++)
        {
            for(int j=index*(JOB_COUNT/JF);j<(index+1)*JOB_COUNT/JF-1-i;j++)
            {
                if(job[j].JSize<job[j+1].JSize)
                {
                     jobchange=job[j];
                     job[j]=job[j+1];
                     job[j+1]=jobchange;
                }
            }
        }
    }
    //batch the jobs ,use FF heuristic
        Batch batch[JOB_COUNT];
    //Batch *p=batch;
    for(int x=0;x<JOB_COUNT;x++)
		for(int y=0;y<JOB_COUNT;y++)
		     batch[x].exist[y]=-1;
    batch[0].BID=0;
    batch[0].Bfamily=job[0].JFamily;
	batch[0].Bptime=job[0].JPtime;
	batch[0].unused_space=B-job[0].JSize;
	batch[0].used_space=job[0].JSize;
    batch[0].exist[0]=job[0].JID;
    int k=0;  //Marked as current used BID
    for(int i=1;i<JOB_COUNT;i++)
    {
         int flag=0;
         for(int j=0;j<=k&&i<JOB_COUNT;j++)  //FF heuristic, job send to the best fit batch
          {
             if(batch[j].unused_space>=job[i].JSize&&batch[j].Bfamily==job[i].JFamily)
             {
                 batch[j].unused_space-=job[i].JSize;
                 batch[j].used_space+=job[i].JSize;
                 int t=0;
                 while(batch[j].exist[t]!=-1) t++;
                 batch[j].exist[t]=job[i].JID;
                 flag=1;
                 break;
             }
         }
         if(flag==0)   //no fited batch ,new one
         {
             k++;
             batch[k].BID=k;
             batch[k].Bfamily=job[i].JFamily;
             batch[k].Bptime=job[i].JPtime;
             batch[k].unused_space=B-job[i].JSize;
             batch[k].used_space=job[i].JSize;
             batch[k].exist[0]=job[i].JID;
         }

    }
     Batch  tempbatch;
     for(int pointer=0;pointer<k/2;pointer++)
     {
         int temp=rand()%k+1;
        // tempbatch.BID=batch[pointer].BID;
         tempbatch.Bfamily=batch[pointer].Bfamily;
         tempbatch.Bptime=batch[pointer].Bptime;
         tempbatch.unused_space=batch[pointer].unused_space;
         tempbatch.used_space=batch[pointer].used_space;
         memcpy(tempbatch.exist,batch[pointer].exist,JOB_COUNT);
         //batch[pointer].BID=batch[temp].BID;
         batch[pointer].Bfamily=batch[temp].Bfamily;
         batch[pointer].Bptime=batch[temp].Bptime;
         batch[pointer].unused_space=batch[temp].unused_space;
         batch[pointer].used_space=batch[temp].used_space;
         memcpy(batch[pointer].exist,batch[temp].exist,JOB_COUNT);
         //batch[temp].BID= tempbatch.BID;
         batch[temp].Bfamily=tempbatch.Bfamily;
         batch[temp].Bptime=tempbatch.Bptime;
         batch[temp].unused_space=tempbatch.unused_space;
         batch[temp].used_space=tempbatch.used_space;
         memcpy(batch[temp].exist,tempbatch.exist,JOB_COUNT);
     }

    //assign batch to machine
 vector<Machine>  machine;
    Machine newmachine;
    for(int i=0;i<M;i++)
    {
        newmachine.MID=i+1;
        newmachine.Mcomplatetime=0;
        machine.push_back(newmachine);
        newmachine.initmachine();
    }

     for(int  pro=0;pro<k;pro++)
     {
         sort(machine,machine.size());
        machine[0].Mcomplatetime+=batch[pro].Bptime;
      }

    sort(machine,machine.size());
    return machine[M-1].Mcomplatetime;
}

//LFLT processing
int LFLT(JOB *job)
{
  //  int sum=0;  //Mark as Cmax;
    //For a job family , sort the job in  decreasing order;
    JOB jobchange;
    for(int index=0;index<JF;index++)
    {
        for(int i=index*(JOB_COUNT/JF);i<(index+1)*JOB_COUNT/JF;i++)
        {
            for(int j=index*(JOB_COUNT/JF);j<(index+1)*JOB_COUNT/JF-1-i;j++)
            {
                if(job[j].JSize<job[j+1].JSize)
                {
                     jobchange=job[j];
                     job[j]=job[j+1];
                     job[j+1]=jobchange;
                }
            }
        }
    }
    //batch the jobs ,use FF heuristic
        Batch batch[JOB_COUNT];
    //Batch *p=batch;
    for(int x=0;x<JOB_COUNT;x++)
		for(int y=0;y<JOB_COUNT;y++)
		     batch[x].exist[y]=-1;
    batch[0].BID=0;
    batch[0].Bfamily=job[0].JFamily;
	batch[0].Bptime=job[0].JPtime;
	batch[0].unused_space=B-job[0].JSize;
	batch[0].used_space=job[0].JSize;
    batch[0].exist[0]=job[0].JID;
    int k=0;  //Marked as current used BID
    for(int i=1;i<JOB_COUNT;i++)
    {
         int flag=0;
         for(int j=0;j<=k&&i<JOB_COUNT;j++)  //FF heuristic, job send to the best fit batch
          {
             if(batch[j].unused_space>=job[i].JSize&&batch[j].Bfamily==job[i].JFamily)
             {
                 batch[j].unused_space-=job[i].JSize;
                 batch[j].used_space+=job[i].JSize;
                 int t=0;
                 while(batch[j].exist[t]!=-1) t++;
                 batch[j].exist[t]=job[i].JID;
                 flag=1;
                 break;
             }
         }
         if(flag==0)   //no fited batch ,new one
         {
             k++;
             batch[k].BID=k;
             batch[k].Bfamily=job[i].JFamily;
             batch[k].Bptime=job[i].JPtime;
             batch[k].unused_space=B-job[i].JSize;
             batch[k].used_space=job[i].JSize;
             batch[k].exist[0]=job[i].JID;
         }
    }



    //sort  the batch in decreasing order of their processing times
    Batch  tempbatch;
    for(int m=0;m<k;m++)
        for(int n=0;n<k-m-1;n++)
        {
            if(batch[n].Bptime<batch[n+1].Bptime)
            {
                 tempbatch.Bfamily=batch[n].Bfamily;
                 tempbatch.Bptime=batch[n].Bptime;
                 tempbatch.unused_space=batch[n].unused_space;
                 tempbatch.used_space=batch[n].used_space;
                 memcpy(tempbatch.exist,batch[n].exist,JOB_COUNT);

                 batch[n].Bfamily=batch[n+1].Bfamily;
                 batch[n].Bptime=batch[n+1].Bptime;
                 batch[n].unused_space=batch[n+1].unused_space;
                 batch[n].used_space=batch[n+1].used_space;
                 memcpy(batch[n].exist,batch[n+1].exist,JOB_COUNT);

                 batch[n+1].Bfamily=tempbatch.Bfamily;
                 batch[n+1].Bptime=tempbatch.Bptime;
                 batch[n+1].unused_space=tempbatch.unused_space;
                 batch[n+1].used_space=tempbatch.used_space;
                 memcpy(batch[n+1].exist,tempbatch.exist,JOB_COUNT);
            }

        }




    //assign batch to machine
 vector<Machine>  machine;
    Machine newmachine;
    for(int i=0;i<M;i++)
    {
        newmachine.MID=i+1;
        newmachine.Mcomplatetime=0;
        machine.push_back(newmachine);
        newmachine.initmachine();
    }

     for(int  pro=0;pro<k;pro++)
     {
         sort(machine,machine.size());
        machine[0].Mcomplatetime+=batch[pro].Bptime;
      }

    sort(machine,machine.size());
    return machine[M-1].Mcomplatetime;
}
//int main()
//{
//     srand((unsigned)time(NULL));
//   fstream inFile;
//   double  totaltime=0;
//   //double t=0;
//  // double  avg=0;
//   int SUM=0;
//   inFile.open("D:\\Copyxiao\\J90_3.txt");
//   if(!inFile.is_open())
//	{
//	    cout<<"Cannot open file!"<<endl;
//		exit(EXIT_FAILURE);
//	}
//	JOB job[JOB_COUNT];
//	for(int i=0;i<JOB_COUNT;i++)
//	{
//		inFile>>job[i].JID>>job[i].JFamily>>job[i].JPtime>>job[i].JSize;
//	}
//		for(int i=0;i<JOB_COUNT;i++)
//	{
//		cout<<job[i].JID<<"\t"<<job[i].JFamily<<"\t"<<job[i].JPtime<<"\t"<<job[i].JSize<<endl;
//	}
//    ofstream outFile("D:\\RESULT\\J90_test_3.xls",ios::app);
//    clock_t start,finish;
//
//	start=clock();
//	for(int repeat=0;repeat<10;repeat++)
//	{
//	   //result[repeat]=RNRN(job);
//	   //result[repeat]=LFRN(job);
//	   result[repeat]=LFLT(job);
//	    SUM+=result[repeat];
//	    outFile<<result[repeat]<<"\t";
//	    cout<<result[repeat]<<"\t";
//	}
//	finish=clock();
//	totaltime=(double)(finish-start)/CLOCKS_PER_SEC;
//   outFile<<SUM/10.0<<"\t"<<totaltime/10.0<<endl;
//   cout<<SUM/10.0<<"\t"<<totaltime/10.0<<endl;
//}
int main()
{
    char* pp[151];
    _finddata_t file;
    int count=0;
    long lf;
    srand((unsigned)time(NULL));
    if((lf = _findfirst("E:\\180\\*.*", &file))==-1)
        {
            cout<<"Not Found!"<<endl;
        }
        else
        {
            //����ļ���
            cout<<"file name list:"<<endl;

            while(_findnext(lf, &file)==0)
            {
                char *a=new char[_MAX_FNAME];

                for(int i=0;i<_MAX_FNAME;i++)
                {
                    a[i]=file.name[i];
                }
                pp[count]=a;
                count++;
            }

        }
    //cout<<pp[0]<<"\t"<<pp[1]<<"\t"<<pp[2];
     double  totaltime=0;
     int SUM=0;
     clock_t start, end;
  //   cout<<count<<endl;
    ofstream outFile("g:\\result0606\\180_RNRN_0606_3.xls",ios::app);
    for(int i=1;i<=10;i++)
        {
            outFile<<i<<"\t";
        }
    outFile<<"AVG"<<"\t"<<"TIME"<<endl;
    for(int fileNum = 1; fileNum < count; fileNum++)
    {
        char fs[100]="E:\\180\\";
        strcat(fs,pp[fileNum]);

        ifstream inFile;
        inFile.open(fs);
        if(!inFile.is_open())
            {
                cout<<"ff"<<endl;
                exit(EXIT_FAILURE);
            }

        JOB job[JOB_COUNT];
        for(int i=0;i<JOB_COUNT;i++)
        {
            inFile>>job[i].JID>>job[i].JFamily>>job[i].JPtime>>job[i].JSize;
        }
        if(fileNum==51||fileNum==101)
        {
            outFile<<endl;
            cout<<endl;
            outFile<<pp[fileNum]<<endl;
            cout<<pp[fileNum]<<endl;
        }

        int result[10];
        cout<<fs<<endl;

        start = clock();
        for(int i = 0; i< 10; i++)
            {
               result[i] = RNRN(job);
//                result[i]=LFRN(job);
//            result[i]=LFLT(job);
                SUM+=result[i];
                outFile<<result[i]<<"\t";
                cout<<result[i]<<"\t";
            }
        end= clock();
        totaltime=(double)(end-start)/CLOCKS_PER_SEC;
        outFile<<SUM/10.0<<"\t"<<totaltime/10.0<<endl;
        SUM=0;
    }
}
