#include<iostream>
#include<fstream>
#include<vector>
#include<cmath>
#include<ctime>
#include<cstring>
#include<algorithm>
using namespace std;
 const int N=180;
 //const int Family=3;
int main()
{
   srand((unsigned)time(NULL));

   for(int sizenum=0;sizenum<3;sizenum++)
   {
       for(int q=0;q<50;q++)
       {
           int jid;
           int jFamily[N]={0};
           int jPtime[N]={0};
           int jSize[N]={0};
           int fTime[3]={0};
           //int jTime[N]={0};
           for(int i=0;i<3;i++)
            {
                fTime[i]=rand()%10+1+10*i;
            }
            for(int i=0;i<N;i++)
            {
                if(i<N/3)
                   {
                      jFamily[i]=1;
                      jPtime[i]=fTime[0];
                   }
                else if((i>=N/3)&&(i<2*N/3))
                {
                    jFamily[i]=2;
                    jPtime[i]=fTime[1];
                }

                else
                {
                    jFamily[i]=3;
                    jPtime[i]=fTime[2];
                }

            }
            if(sizenum==0)
           {
              for(int i=0;i<N;i++)
              {
                  jSize[i]=rand()%35+1;
              }
           }
           else if(sizenum==1)
           {
              for(int i=0;i<N;i++)
              {
                  jSize[i]=rand()%35+15;
              }
           }
            else if(sizenum==2)
           {
              for(int i=0;i<N;i++)
              {
                  jSize[i]=rand()%50+1;
              }
           }
           else
            cout<<"error!!"<<endl;

        ofstream outfile;
        char filename[50];
        sprintf(filename,"G:\\data0606\\180\\%d_%d_%d.txt",N,sizenum,q);
        outfile.open(filename,fstream::app);
        if(!outfile)
        {
            cout<<"��ʧ��"<<endl;
            exit(1);
        }
        for(int i=0;i<N;i++)
        {
            jid=i+1;
            printf("%d          %d          %d     %d\n",jid,jFamily[i],jPtime[i],jSize[i]);
            outfile<<jid<<"\t"<<jFamily[i]<<"\t"<<jPtime[i]<<"\t"<<jSize[i]<<endl;

        }
        outfile.close();
       }
   }
    return 0;
}
