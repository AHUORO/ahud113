package com.shdx.BFLPT2.Scheduling;
import java.io.IOException;
import java.util.ArrayList;
public class BFLPT {         //ʹ��BFLPT������з���
	static int scheNum = 0;  //����Ѿ����ȵ���ҵ��
	static ArrayList<Batch> batchs = new ArrayList<Batch>();
	public static void bflpt(Job[] jobs) throws IOException {
		//����ҵ���ӹ�ʱ����н�������
		for (int i = 0; i < jobs.length; i++) {
			for (int j = 1; j < jobs.length-i; j++) {
				if(jobs[j-1].jTime < jobs[j].jTime) {
					Job tempJob;
					tempJob = jobs[j];
					jobs[j] = jobs[j-1];
					jobs[j-1] = tempJob;
				}
			}
		}
		
		//batchs = new ArrayList<Batch>();    //���ڴ洢�ֺõ���
		ArrayList<Batch> tempBatchs = new ArrayList<Batch>();
		//����ҵ���з���
		Batch batch = new Batch();
		batchs.add(batch);
		for (int i = 0; i < Prepare.jNum; i++) {
			for(int j = 0; j<batchs.size(); j++) {
				//�Ƚ��ܹ��Ž�����i�������뵽����tempBatchs��
				Batch  batchTemp = (Batch)batchs.get(j);
				if((batchTemp.surSize) >= Prepare.jobs[i].jSize) {
					tempBatchs.add(batchTemp);
				}
			}
			if(tempBatchs.size() != 0) {
				int flag =0; 
				int minSize = 10000;
				//����tempBatchs��ѡ���ʣ��������С����
				for (int k = 0; k < tempBatchs.size(); k++) {
					Batch  batchTemp = (Batch)tempBatchs.get(k);
					if(batchTemp.surSize < minSize) {
						minSize = batchTemp.surSize;
						flag = k;
					}
				}
				Batch  batchTemp = (Batch)tempBatchs.get(flag);
				batchTemp.packBatch(Prepare.jobs[i]);
				tempBatchs.clear();
			}
			else {
				Batch batch2 = new Batch();
				batch2.packBatch(Prepare.jobs[i]);
				batchs.add(batch2);
			}
			
		}
		
		
//		for (int j = 0; j < batchs.size(); j++) {
//			Batch  batchTemp = (Batch)batchs.get(j);
//			for (int j2 = 0; j2 < batchTemp.existList.size(); j2++) {
//				System.out.print(((Job)batchTemp.existList.get(j2)).jNum);
//				System.out.println();
//			}
//			System.out.println();
//			System.out.println("���ĳߴ磺" + batchTemp.bSize);
//			System.out.println("���ļӹ�ʱ�䣺" + batchTemp.bTime);
//			System.out.println();
//			
//		}
//		
//		System.out.println(batchs.size());
//		Prepare.bwr.write(batchs.size());
//		Prepare.bwr.newLine();
//		Prepare.bwr.flush();
		
		
	}
	
	
	


}
