package com.shdx.Scheduling;

import java.util.ArrayList;

public class Machine {
	int mComTime = 0;   //�������깤ʱ��
	ArrayList<Batch> exist = new ArrayList<Batch>();
	
	public void schedule(Batch batch) {    
			this.mComTime = this.mComTime + batch.bTime;        //���»����ļӹ�ʱ��
			this.exist.add(batch);
		
	}
	public void initMachine() {
		this.mComTime = 0;
		exist.clear();
	}
	
}
