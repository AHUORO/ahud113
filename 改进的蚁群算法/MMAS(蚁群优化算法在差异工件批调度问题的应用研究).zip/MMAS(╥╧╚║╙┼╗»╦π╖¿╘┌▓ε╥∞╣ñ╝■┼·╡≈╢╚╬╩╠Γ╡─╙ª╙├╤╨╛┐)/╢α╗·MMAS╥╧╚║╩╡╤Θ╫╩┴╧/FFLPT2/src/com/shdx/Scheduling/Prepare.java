package com.shdx.Scheduling;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Prepare {
	
	static int jNum = Scheduling.JobNum;   //������ҵ��
	static Job[] jobs;
	static BufferedWriter bwr;
	
	public static void calculate() throws IOException {
		File test= new File(Scheduling.fileName);  //�����ļ�
		File file=new File(Scheduling.fileResult);   //����ļ�
		if(!file.exists())
            file.createNewFile();         //����ļ������ڣ������ļ�
		FileReader fr = new FileReader(test);
		BufferedReader br = new BufferedReader(fr);
		FileWriter wr = new FileWriter(file,true);
		bwr = new BufferedWriter(wr);
		

		//System.out.println(jNum);
		
		
		//���ı����ݵ��������
		jobs = new Job[jNum];
		for (int i = 0; i < jobs.length; i++) {
			jobs[i] = new Job();
			String str = br.readLine();
			String[] temp = str.split("\\s+");
			jobs[i].jNum = Integer.parseInt(temp[0]);
			jobs[i].jTime = Integer.parseInt(temp[1]);
			jobs[i].jSize = Integer.parseInt(temp[2]);
			jobs[i].jFlag = true;  
		}
		
//		String str;
//		int i = 0;
//		while ((str = br.readLine()) != null) {
////			System.out.println(str);
//			String[] temp = str.split("\\s+");
//			jobs[i].jNum = Integer.parseInt(temp[0]);
//			jobs[i].jTime = Integer.parseInt(temp[1]);
//			jobs[i].jSize = Integer.parseInt(temp[2]);
//			jobs[i].jFlag = true;  
//			i++;
//		}
		br.close();
		
	}
}
